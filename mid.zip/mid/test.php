<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Control Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" type="text/css" href="css/sweetalert-raw.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.5/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/controlpanel.css">
    <link rel="stylesheet" type="text/css" href="css/editor.css">
    <link rel="stylesheet" href="//cdn.jsdelivr.net/chartist.js/latest/chartist.min.css">
    <link rel="shortcut icon" type="image/png" href=favicon.png>

    <!--[if lt IE 9]>
            <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
</head>





<body>
    <div class="navbar-fixed">
        <nav class="cyan">
            <div class="nav-wrapper">

                <ul class="left">
                    <li>
                        <h1 class="logo-wrapper"><a href="dashboard.php" class="brand-logo darken-1"><img src="images/mini-logo-sitewide.png" alt="Capsule"></a> <span class="logo-text"></span></h1></li>
                </ul>
                <ul class="right hide-on-med-and-down">
                    <li><a href="javascript:void(0);" class="waves-effect waves-block waves-light toggle-fullscreen" onClick="alert('your schedule lies here');"><i class="mdi-editor-insert-invitation"></i></a>
                    </li>
                    <li><a href="codepad.php" class="waves-effect waves-block waves-light"><i class="mdi-editor-insert-drive-file"></i></a>
                    </li>
                    <li><a href="javascript:void(0);" class="waves-effect waves-block waves-light" onClick="alert('lets change the password');"><i class="mdi-action-settings"></i></a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
    <!-- navbar ended | do not fiddle! SPECIALY SWAPPY :@ :P -->
    <div class='row'>
        <div class="col s2  grey lighten-3">
            <!-- left panel -->
            <!-- START LEFT SIDEBAR NAV-->
            <aside id="left-sidebar-nav">
                <ul id="slide-out" class="side-nav fixed leftside-navigation">
                    <li class="user-details cyan darken-2" id='gradient'>
                        <div class="row">
                            <div class="col col s4 m4 l4">
                                <img src="images/avatar.png" alt="" class="circle responsive-img valign profile-image">
                            </div>
                            <div class="col col s8 m8 l8">
                                <span class="btn-flat dropdown-button waves-effect waves-light white-text profile-btn" href="#" data-activates="profile-dropdown"><b> <?php echo("Faculty Name");?> </b></span>
                                <p class="user-roal">
                                    <?php echo "Some Info ";?>
                                </p>
                            </div>
                        </div>
                    </li>
                    <li class="bold active"><a href="dashboard.php" class="waves-effect waves-cyan"><i class="mdi-action-dashboard"></i>Desk</a>
                    </li>
                    <li class="bold"><a href="#editor-container" class="modal-trigger waves-effect waves-cyan"><i class="mdi-action-assignment"></i> Editor</a>
                    </li>
                    <li class="bold"><a href="php_inc/logout.php" class="waves-effect waves-cyan"><i class="material-icons dp48">power_settings_new</i>Logout</a>
                    </li>
                </ul>
            </aside>
        </div>
        <!-- sidebar ends | do not fiddle! SPECIALY SWAPPY :@ :P-->

        <div class="col s12 white">
            <div id="main">

                <div class="row">
                    <div id="card-stats">
                        <div class="row">
                            <div class="col s12 m6 l3">
                                <div class="card">
                                    <div class="card-content  green white-text">
                                        <p class="card-stats-title"><i class="mdi-social-group-add"></i> New Submissions</p>
                                        <h4 class="card-stats-number">566</h4>
                                        <p class="card-stats-compare"><i class="mdi-hardware-keyboard-arrow-up"></i> 15% <span class="green-text text-lighten-5">from yesterday</span>
                                        </p>
                                    </div>
                                    <div class="card-action  green darken-2">
                                        <div id="submission-bar"> put some infographics here for visuals</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col s12 m6 l3">
                                <div class="card">
                                    <div class="card-content purple white-text">
                                        <p class="card-stats-title"><i class="mdi-social-group-add"></i> Questions</p>
                                        <h4 class="card-stats-number">566</h4>
                                        <p class="card-stats-compare"><i class="mdi-hardware-keyboard-arrow-up"></i> 15% <span class="green-text text-lighten-5">from yesterday</span>
                                        </p>
                                    </div>
                                    <div class="card-action purple darken-2">
                                        <div id="submission-bar"> put some infographics here for visuals</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col s12 m6 l3">
                                <div class="card">
                                    <div class="card-content blue-grey white-text">
                                        <p class="card-stats-title"><i class="mdi-social-group-add"></i> New Submissions</p>
                                        <h4 class="card-stats-number">566</h4>
                                        <p class="card-stats-compare"><i class="mdi-hardware-keyboard-arrow-up"></i> 15% <span class="green-text text-lighten-5">from yesterday</span>
                                        </p>
                                    </div>
                                    <div class="card-action blue-grey darken-2">
                                        <div id="submission-bar"> put some infographics here for visuals</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col s12 m6 l3">
                                <div class="card">
                                    <div class="card-content pink lighten-2 white-text">
                                        <p class="card-stats-title"><i class="mdi-social-group-add"></i> New Submissions</p>
                                        <h4 class="card-stats-number">566</h4>
                                        <p class="card-stats-compare"><i class="mdi-hardware-keyboard-arrow-up"></i> 15% <span class="green-text text-lighten-5">from yesterday</span>
                                        </p>
                                    </div>
                                    <div class="card-action  pink darken-2">
                                        <div id="submission-bar"> put some infographics here for visuals</div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col s12 m4">
                    <ul id="task-card" class="collection with-header">
                        <li class="collection-header red">
                            <h4 class="task-card-title">Pendings</h4>
                            <p class="task-card-date">February 25, 2016</p>
                        </li>
                        <li class="collection-item dismissable  red lighten-5">
                            <input type="checkbox" id="task1" />
                            <label for="task1">Create Teacher's UI. <a href="#" class="secondary-content"><span class="ultra-small">Today</span></a>
                            </label>
                            <span class="task-cat teal">Front End</span>
                        </li>
                        <li class="collection-item dismissable  red lighten-5">
                            <input type="checkbox" id="task2" />
                            <label for="task2">Update Server Code <a href="#" class="secondary-content"><span class="ultra-small">Monday</span></a>
                            </label>
                            <span class="task-cat purple">Evaluator</span>
                        </li>
                        <li class="collection-item dismissable  red lighten-5">
                            <input type="checkbox" id="task3" checked="checked" />
                            <label for="task3">Check the new Mockup. <a href="#" class="secondary-content"><span class="ultra-small">Wednesday</span></a>
                            </label>
                            <span class="task-cat pink">Mockup</span>
                        </li>
                        <li class="collection-item dismissable  red lighten-5">
                            <input type="checkbox" id="task4" checked="checked" />
                            <label for="task4">Get questions running.</label>
                            <span class="task-cat cyan">Student-Teacher Bridge</span>
                        </li>
                        <li class="collection-item red lighten-5">

                            <input type="text" placeholder="New Task" name="task-adder">


                        </li>
                    </ul>
                </div>
                </div>

            </div>
        </div>
    </div>

    <footer class="page-footer cyan">
        <div class="footer-copyright">
            <div class="container"> © 2016 | <a class="grey-text text-lighten-4">Whatthetech.in |</a> All rights reserved.
                <span class="right"> Design and Developed by <a class="grey-text text-lighten-4">Group #54 | Final Year Project| 2015-2016 | ABES Engineering College</a></span>
            </div>
        </div>
    </footer>

    <!-- editor modal-->
    <div id="editor-container" class="modal">
        <div class="modal-content" style='overflow:hidden;'>
            <div id='buttons'>
                <input type='text' id='sherlock' placeholder="Search" style='margin-top:-10px;'>
                <input type='button' id='but-sea' onClick='find();' title="Search">
                <input type='button' id='but-ref' onClick='flush();' title="Reset">
                <input type='button' id='but-sub' title="Submit">
                <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat " style='margin-left:53%;'><img src="images/close.png"></a>
            </div>

            <div id="texty">
                <pre id="editor"><code></code></pre>

                <script src="ace/ace.js" type="text/javascript" charset="utf-8"></script>
                <script>
                    var editor = ace.edit("editor");
                    editor.setTheme("ace/theme/chaos");
                    editor.session.setMode("ace/mode/c_cpp");
                    editor.setAutoScrollEditorIntoView(true);
                    editor.setOption("showPrintMargin", false);
                </script>
            </div>
            <hr style='margin-top:2px;'>
            <div class="modal-footer" style='background-color: #000000;'>
                <div id='console-io' style=' height:100%;'>
                    <textarea id="stdin" style="width: 100%; height: 90%; display:inline-block;color:red; outline:none; border:none;"></textarea>
                </div>
                <div id="cmlogo">
                    <img class="bottom" src="images/mini-bw.png" />
                    <img class="top" src="images/mini-col.png" />
                </div>
            </div>

        </div>



    </div>

    <!--response modal-->
    <div id="response-container" class="modal">
        <div class="modal-content" style='overflow:hidden;'>
            <h4 class="modal-title" id="myModalLabel" style='text-align:center;'> Submission Sheet </h4>
            <hr>
            <div class="modal-body">
                <label>Language: </label> <span id="language"></span>
                <br>
                <label>Time: </label><span id="time"> </span>
                <br>
                <label>Memory: </label><span id="memory"></span>
                <br>
                <label>Result: </label><span id="result"></span>
                <br>
                <label>Output: </label><span id="output"></span>
            </div>

            <div class="input-field col s6 m6 l6 center">
                <p class="margin medium-small btn"><a href="#!" class=" modal-action modal-close waves-effect waves-blue btn-flat">Close</a></p>
            </div>

        </div>
    </div>


    <!--scripts-->
    <script src="js/jquery.js"></script>
    <script type="text/javascript" src='js/controlpanel.js'></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.5/js/materialize.min.js"></script>
    <script type="text/javascript" src="js/grad_dp.js"></script>
    <!--no changes-->
    <script type="text/javascript" src='js/sweetalert.js'></script>
    <script src="//cdn.jsdelivr.net/chartist.js/latest/chartist.min.js"></script>
    <script type="text/javascript">
        $('.modal-trigger').leanModal({
            dismissible: false,
            opacity: .5,
            in_duration: 300,
            out_duration: 200,

        });
    </script>
</body>




</html>