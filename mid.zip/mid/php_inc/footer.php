  <footer class="page-footer cyan">
        <div class="footer-copyright">
            <div class="container"> © 2016 | <a class="grey-text text-lighten-4">Whatthetech.in |</a> All rights reserved.
                <span class="right"> Design and Developed by <a class="grey-text text-lighten-4">Group #54 | Final Year Project| 2015-2016 | ABES Engineering College</a></span>
            </div>
        </div>
    </footer>