<div class="navbar-fixed">
            <nav class="cyan">
                <div class="nav-wrapper">                    
                    
                    <ul class="left">                      
                      <li><h1 class="logo-wrapper"><a href="dashboard.php" class="brand-logo darken-1"><img src="images/mini-logo-sitewide.png" alt="Capsule"></a> <span class="logo-text"></span></h1></li>
                    </ul>
                    <ul class="right hide-on-med-and-down">                        
                        <li><a href="javascript:void(0);" class="waves-effect waves-block waves-light toggle-fullscreen" onClick="alert('your schedule lies here');"><i class="mdi-editor-insert-invitation"></i></a>
                        </li>
                        <li><a href="codepad.php" class="waves-effect waves-block waves-light"><i class="mdi-editor-insert-drive-file"></i></a>
                        </li>                        
                        <li><a href="javascript:void(0);" class="waves-effect waves-block waves-light" onClick="alert('lets change the password');"><i class="mdi-action-settings"></i></a>
                        </li>                        
                    </ul>
                </div>
            </nav>
        </div>